// Actividad 2.1: programa que hace algunas operaciones con fracciones
#include "iostream"
#include "Racional.h"

using namespace std;

// Pedimos los datos
Racional leerDatos()
{
	// Variables para guardar numerador y denominador que capturamos por teclado
	int numerador, denominador;
	do {
		cout << "Introduzca numerador y denominador (separado por espacios) del racional a.\nEl denominador debe ser distinto de cero: ";
		cin >> numerador;
		cin >> denominador;
	} while (denominador == 0);
	return (Racional(numerador, denominador));
}


int main()
{
	// Pedimos y creamos el primer racional
	Racional a = leerDatos();

	cout << "Racional a: ";
	a.escribir();
	cout << endl;

	// Pedimos y creamos el segundo racional
	Racional b = leerDatos();

	cout << "Racional b: ";
	b.escribir();
	cout << endl;

	// Realizamos la suma y lo imprimimos
	Racional resultado = a.sumar(b); // Resultado de las operaciones
	cout << "Racional a+b: ";
	resultado.escribir();
	cout << endl;

	// Simplificamos y lo escribimos
	resultado.simplificar();
	cout << "Racional a+b simplificado: ";
	resultado.escribir();
	cout << endl;

	// Realizamos la multiplicaci�n y lo escribimos
	resultado = a.multiplicar(b);
	cout << "Racional a*b: ";
	resultado.escribir();
	cout << endl;

	// Simplificamos y lo escribimos
	resultado.simplificar();
	cout << "Racional a*b simplificado: ";
	resultado.escribir();
	cout << endl;
	return 0;
}
