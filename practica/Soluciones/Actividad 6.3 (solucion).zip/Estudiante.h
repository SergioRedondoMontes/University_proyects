#pragma once
#include "string"
using namespace std;

// Estructura que representa a un estudiante
struct Estudiante {
	int clave;
	string nombre;
};
