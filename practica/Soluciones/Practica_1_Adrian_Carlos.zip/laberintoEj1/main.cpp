// Developed by Adrian Naranjo & Carlos Rodriguez - 28/02/19

#include <iostream>

bool is_empty(char **board, int posX, int posY)
{
    if (board[posX][posY] == '-')
    {
        return true;
    }
    return false;
}

bool is_valid(char **board, int filas, int columnas, int posX, int posY)
{
    if ((posX < filas && posY < columnas) && (posX >= 0 && posY >= 0))
    {
        return true;
    }
    return false;
}

bool buscar(char **board, int filas, int columnas, int posX, int posY, int posXEnd, int posYEnd)
{
    // std::cout << "Entro buscar" << std::endl;
    if (posX == posXEnd && posY == posYEnd)
    {
        if (is_empty(board, posX, posY))
        {
            board[posX][posY] = '>';
            // std::cout << "Llego final" << std::endl;
            return true;
        }
        return false;
    }

    if (is_valid(board, filas, columnas, posX, posY))
    {
        if (is_empty(board, posX, posY))
        {

            // std::cout << "Esta vacia la posicion" << std::endl;
            board[posX][posY] = '>';
        }
        else
        {
            return false;
        }
        // Movimiento arriba
        if (buscar(board, filas, columnas, posX - 1, posY, posXEnd, posYEnd))
        {
            return true;
        }
        // Movimiento derecha
        else if (buscar(board, filas, columnas, posX, posY + 1, posXEnd, posYEnd))
        {
            return true;
        }
        // Movimiento abajo
        else if (buscar(board, filas, columnas, posX + 1, posY, posXEnd, posYEnd))
        {
            return true;
        }
        // Movimiento izquierda
        else if (buscar(board, filas, columnas, posX, posY - 1, posXEnd, posYEnd))
        {
            return true;
        }
        else
        {
            board[posX][posY] = '?';
            // std::cout << "Camino incorrecto" << std::endl;
            return false;
        }
    }

    return false;
}

char *crearArray(int tamano)
{
    char *array = (char *)malloc(sizeof(char) * tamano);
    char letra;
    for (int i = 0; i < tamano; i++)
    {
        letra = '-';
        array[i] = letra;
    }

    return array;
}

/* VOID PARA CREAR MATRIZ */

char **crearMatriz(int columnas, int filas)
{
    char **matriz = (char **)malloc(sizeof(malloc(sizeof(char) * columnas)) * filas);

    for (int i = 0; i < filas; i++)
    {
        matriz[i] = crearArray(columnas);
    }

    return matriz;
}

void mostrarArray(char *array, int columnas)
{
    for (int i = 0; i < columnas; i++)
    {
        std::cout << array[i] << " ";
    }
    std::cout << std::endl;
}

void mostrarMatriz(char **matriz, int columnas, int filas)
{
    for (int i = 0; i < filas; i++)
    {
        mostrarArray(matriz[i], columnas);
    }
}

void liberarMatriz(char **matriz, int cantidadArrays)
{
    for (int i = 0; i < cantidadArrays; i++)
    {
        free(matriz[i]);
    }
    free(matriz);
}

int main()
{
    int filas = 0;
    int columnas = 0;
    do
    {
        int temp;
        std::cout << "Introduce el numero de filas" << std::endl;
        std::cin >> temp;
        if (temp > 0)
            filas = temp;
    } while (filas == 0);

    do
    {
        int temp;
        std::cout << "Introduce el numero de columnas" << std::endl;
        std::cin >> temp;
        if (temp > 0)
            columnas = temp;
    } while (columnas == 0);

    char **matriz1 = crearMatriz(filas, columnas);
    int posX, posY;
    do
    {
        std::cout << "Introduce las casillas bloqueadas" << std::endl;
        std::cin >> posX >> posY;
        if (posX > 0 && posX <= columnas && posY > 0 && posY <= filas)
            matriz1[posX - 1][posY - 1] = 'X';
    } while (posX != 0 && posY != 0);

    int posXStart, posYStart = posXStart = 0;

    do
    {
        std::cout << "Introduce la casilla de incio" << std::endl;
        std::cin >> posXStart >> posYStart;
        if (posXStart < 0 || posXStart > columnas || posYStart < 0 || posYStart > filas)
        {
            posYStart = posXStart = 0;
        }

    } while (posXStart == 0 && posYStart == 0);
    posXStart--;
    posYStart--;
    int posXEnd, posYEnd = posXEnd = 0;

    do
    {
        std::cout << "Introduce la casilla de final" << std::endl;
        std::cin >> posXEnd >> posYEnd;
        if (posXEnd < 0 || posXEnd > columnas || posYEnd < 0 || posYEnd > filas)
        {
            posYEnd = posXEnd = 0;
        }

    } while (posXEnd == 0 && posYEnd == 0);

    posXEnd--;
    posYEnd--;

    mostrarMatriz(matriz1, filas, columnas);

    bool finalizado = buscar(matriz1, filas, columnas, posXStart, posYStart, posXEnd, posYEnd);

    if (finalizado)
    {
        std::cout << "Se ha finalizado correctamente" << std::endl;
    }
    else
    {
        std::cout << "No se ha encontrado ninguna solucion" << std::endl;
    }

    mostrarMatriz(matriz1, filas, columnas);

    liberarMatriz(matriz1, filas);

    return 0;
}
