// Developed by Adrian Naranjo & Carlos Rodriguez - 28/02/19

#include <iostream>

void showInConsole(int sudoku[9][9], unsigned int numOfArray, unsigned int size)
{

    for (int i = 0; i < numOfArray; i++)
    {
        for (int j = 0; j < size; j++)
        {
            std::cout << sudoku[i][j] << " ";
        }
        std::cout << std::endl;
    }
}
int esValido(int sudoku[9][9], int fila, int columna, int valor)
{

    if (sudoku[fila][columna] != -1)
        return 1;

    for (int i = 0; i < 9; i++)
    {
        if (sudoku[fila][i] == valor)
            return -1;
    }

    for (int i = 0; i < 9; i++)
    {
        if (sudoku[i][columna] == valor)
            return -1;
    }

    int despFila = (fila / 3) * 3;
    int despColumna = (columna / 3) * 3;

    for (int i = despFila; i < despFila + 3; i++)
    {
        for (int j = despColumna; j < despColumna + 3; j++)
        {
            if (sudoku[i][j] == valor)
                return -1;
        }
    }

    return 0;
}

bool solve(int sudoku[9][9], int fila, int columna)
{
    if (fila == 8 && columna == 8)
    {
        if (sudoku[fila][columna] == -1)
        {
            bool salirWhile = false;
            int value = 1;
            while (!salirWhile && value < 10)
            {
                if (esValido(sudoku, fila, columna, value) == 0)
                {
                    sudoku[fila][columna] = value;
                    return true;
                }
                value++;
            }
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        if (sudoku[fila][columna] == -1)
        {

            bool salirWhile = false;
            int value = 1;
            while (!salirWhile && value < 10)
            {

                if (esValido(sudoku, fila, columna, value) == 0)
                {
                    sudoku[fila][columna] = value;
                    if (columna == 8)
                    {
                        salirWhile = solve(sudoku, fila + 1, 0);
                    }
                    else
                    {
                        salirWhile = solve(sudoku, fila, columna + 1);
                    }

                    if (!salirWhile)
                        sudoku[fila][columna] = -1;
                }
                value++;
            }
            if (!salirWhile)
                return false;
        }
        else
        {
            //Ya existia
            if (columna == 8)
            {
                return solve(sudoku, fila + 1, 0);
            }
            else
            {
                return solve(sudoku, fila, columna + 1);
            }
        }
    }
    return true;
}

void resolverSudoku(int sudoku[9][9])
{
    bool a = solve(sudoku, 0, 0);
    return;
}

int main()
{

    int sudoku[9][9] = {{5, 3, -1, -1, 7, -1, -1, -1, -1},
                        {6, -1, -1, 1, 9, 5, -1, -1, -1},
                        {-1, 9, 8, -1, -1, -1, -1, 6, -1},
                        {8, -1, -1, -1, 6, -1, -1, -1, 3},
                        {4, -1, -1, 8, -1, 3, -1, -1, 1},
                        {7, -1, -1, -1, 2, -1, -1, -1, 6},
                        {-1, 6, -1, -1, -1, -1, 2, 8, -1},
                        {-1, -1, -1, 4, 1, 9, -1, -1, 5},
                        {-1, -1, -1, -1, 8, -1, -1, 7, 9}};
    showInConsole(sudoku, 9, 9);
    resolverSudoku(sudoku);
    std::cout << "---" << std::endl;
    showInConsole(sudoku, 9, 9);
    return 0;
}