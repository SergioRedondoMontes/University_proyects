#include <iostream>

#include <time.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

/*
 * Swap the n dimenstional square submatrices of a matrix.
 * - matrix: matrix with the data.
 * - n: size of the square submatrix.
 * - initRowA: initial row of submatrix A.
 * - initColA: initial column of submatrix A.
 * - initRowB: initial row of submatrix B.
 * - initColB: initial column of submatrix B.
 */
void swap (int **matrix, int n, int initRowA, int initColA, int initRowB, int initColB) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int aux = matrix[initRowA + i][initColA + j];
            matrix[initRowA + i][initColA + j] = matrix[initRowB + i][initColB + j];
            matrix[initRowB + i][initColB + j] = aux;
        }
    }
}

/*
 * Transpose the matrix using divide and conquer strategy.
 * - matrix: matrix with the data.
 * - initRow: initial row of the submatrix to be transposed.
 * - endRow: last row of the submatrix to be transposed.
 * - initCol: initial column of the submatrix to be transposed.
 * - endCol: last column of the submatrix to be transposed.
 */
void divideAndConquer (int **matrix, int initRow, int endRow, int initCol, int endCol) {
    if (initRow == endRow - 1) {
        int aux = matrix[initRow][endCol];
        matrix[initRow][endCol] = matrix[endRow][initCol];
        matrix[endRow][initCol] = aux;
    } else {
        int middleRow = (initRow + endRow) / 2;
        int middleCol = (initCol + endCol) / 2;
        
        divideAndConquer(matrix, initRow, middleRow, initCol, middleCol);
        divideAndConquer(matrix, initRow, middleRow, middleCol + 1, endCol);
        divideAndConquer(matrix, middleRow + 1, endRow, initCol, middleCol);
        divideAndConquer(matrix, middleRow + 1, endRow, middleCol + 1, endCol);
        
        swap(matrix, endRow - middleRow, middleRow + 1, initCol, initRow, middleCol + 1);
    }
}

/*
 * Transpose a square matrix (n*n) where n=2^k.
 * - matrix: matrix with the data.
 * - n: matrix size.
 */
void transpose (int **matrix, int n) {
    divideAndConquer(matrix, 0, n-1, 0, n-1);
}

/*
 * Print a square matrix.
 * - matrix: matrix with the data.
 * - n: matrix size.
 */
void printMatrix (int **matrix, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main (int argc, const char * argv[]) {
    
    srand(time(NULL));
   
    int k = 4;
    
    int size = pow(2, k);
    
    int ** matrix = new int* [size];
    for (int i = 0; i < size; i++) {
        matrix[i] = new int [size];
        for (int j = 0; j < size; j++) {
            matrix[i][j] = rand() % 10;
        }
    }
    
    cout << "Initial matrix:" << endl;
    printMatrix(matrix, size);
    
    transpose(matrix, size);
    
    cout << "Transposed matrix:" << endl;
    printMatrix(matrix, size);
    
    return 0;
}
