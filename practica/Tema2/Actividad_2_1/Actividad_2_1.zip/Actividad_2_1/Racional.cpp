#include "Racional.h"

Racional::Racional(int a, int b)
{
    numerador=a;
    denominador=b;
}

int Racional::getNumerador() {return numerador; }
int Racional::getDenominador(){return denominador; }
int Racional::suma(){return denominador; }
int Racional::multiplicacion(){return denominador; }