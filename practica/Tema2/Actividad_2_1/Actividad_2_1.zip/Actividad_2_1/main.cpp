#include <iostream>
#include <string>
#include "Racional.h"

using namespace std;

int main(){

    Racional numero(1,2);
    std::cout << numero.getDenominador();

}