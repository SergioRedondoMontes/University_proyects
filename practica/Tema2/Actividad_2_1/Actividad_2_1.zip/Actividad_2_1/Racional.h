class Racional
{
private:
    int numerador;
    int denominador;
public:
    Racional(int a, int b);
    int getNumerador();
    int getDenominador();
    int suma();
    int multiplicacion();
};