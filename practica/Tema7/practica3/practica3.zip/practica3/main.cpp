//
//  main.cpp
//  practica3
//
//  Created by Sergio Redondo on 06/05/2019.
//  Copyright © 2019 NBTech. All rights reserved.
//

#include <iostream>
#include "Orden.h"
    
int main(int argc, const char * argv[]) {
    // insert code here...
    int size;
    std::cout << "Insertar el size: ";
    std::cin >> size;
    
    // Es necesario *?
    ListaContigua bubble;
    
    srand(time(NULL));
    //int *temp = (int *)malloc(sizeof(int) * size);
    for (int i = 0; i < size; i++)
    {
        bubble.insertarAlFinal(rand() % 100);
    }
    /*
     orden.mostrarLista(&bubble);
     orden.insertionSort(&bubble, 1);
     orden.mostrarLista(&bubble);
     */
    Orden orden;
    float numeroClicksInicio = clock();
    orden.mostrarLista(&bubble);
    orden.quickSort(&bubble, DESC);
//    orden.mergeSort(&bubble, DESC);
    orden.mostrarLista(&bubble);
    float numeroClicksFin = clock();
    float segundosTranscurridos = ((float)numeroClicksFin - numeroClicksInicio) / CLOCKS_PER_SEC;
    printf("Con ordenacion por Seleccion en caso general he tardado %.3f segundos.\n", segundosTranscurridos);
    if (orden.isOrdenada(&bubble, ASC) == false) printf(">>>> EL ALGORITMO NO HA FUNCIONADA CORRECTAMENTE!!! <<<<\n");
    
    return 0;
}
